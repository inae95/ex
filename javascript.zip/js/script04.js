function reClock(tmp){
  if(tmp<=9){
    tmp = '0' + tmp;
    }
    return tmp;
}
fnTiming();
setInterval(fnTiming,1000);