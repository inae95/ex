'use strict';

alert('안녕하세요');
document.write('어서오세요');
document.write(prompt('너의 이름은?')+'님 환영합니다.');
document.write('<h1>안녕</h1>');
console('javascript');