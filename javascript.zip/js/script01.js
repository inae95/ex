function darkLight(){

  if(btn.value=='Dark'){
    darkMode();
  } else {
    lightMode();
  }
}