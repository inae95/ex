function darkMode(){
  //다크모드 스타일
btn.value='Light';
btn.style.backgroundColor='turquoise';
body.style.backgroundColor='black';
// aTag[0].style.color='red';
// aTag[1].style.color='red';
// aTag[2].style.color='red';
// aTag[3].style.color='red';
for(var cnt=0;cnt<=3;cnt++){
aTag[cnt].style.color='red'
}
h2.style.color='#fff';
// pTag[0].style.color='#fff';
// pTag[1].style.color='#fff';
for(var cnt=0;cnt<=1;cnt++){
pTag[cnt].style.color='#fff'
}
}