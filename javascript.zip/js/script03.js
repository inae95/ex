
  function lightMode(){
    //라이트모드 스타일
btn.value='Dark';
btn.style.backgroundColor='teal';
body.style.backgroundColor='white';
  // aTag[0].style.color='blue';
  // aTag[1].style.color='blue';
  // aTag[2].style.color='blue';
  // aTag[3].style.color='blue';
for(var cnt=0;cnt<=3;cnt++){
  aTag[cnt].style.color='blue'
}
h2.style.color='#000';
  // pTag[0].style.color='#000';
  // pTag[1].style.color='#000';
for(var cnt=0;cnt<=1;cnt++){
  pTag[cnt].style.color='#000'
}
}